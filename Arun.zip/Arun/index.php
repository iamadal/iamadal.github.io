<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Student Management System - Green University</title>
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/bootstrap-reboot.min.css">
    <link rel="icon" type="image/png" sizes="16x16" href="img/favicon.png">
	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
</head>
<body>
     <img class="uni-logo" src="img/uni-logo.jpg" alt="logo" height="100px" width="100px"/> 
	 <h3 class='title-main' style="display:inline-block">Green University<br><span class="title">Student Management System</span></h3>

     <div class="nav-main">
	  <ul>
	  	<li><a href="#"> <i class="fa fa-home"></i> Home</a></li>
	  	<li><a href="#"> <i class="fa fa-address-card-o"></i> Register</a></li>
	  	<li><a href="#"> <i class="fa fa-info"></i> Find</a></li>
	  </ul>
	 </div>

  <div class="container">
    <div class="row">
	   <div class="col-md-12">
	      <div class="login">
		     <h3>Login to your account</h3>
		     <input type="text" class="form-control" />
		     <input type="password" class="form-control" />
		     <input type="text" class="btn btn-primary bn" value="Login" />
			 <p><a href="#">Or Register Here</a></p>
		  </div>
	   </div>
	</div>
  </div>
  
	<div class="row footer-section"> <!-- Footer -->
	 <div class="col-md-4">
			<p>Degree Offered</p>
			<ul>
				<li><a href="#"><i class="fa fa-book"></i> BSc in CSE</a></li>
				<li><a href="#"><i class="fa fa-book"></i> MSc in CSE</a></li>
				<li><a href="#"><i class="fa fa-book"></i> PGD in CSE</a></li>
			</ul>
	 </div>
	 <div class="col-md-4">
	  <p>Our Students</p>
	   <ul>
	   	<li><a href="#"></a></li>
	   	<li><a href="#"></a></li>
	   	<li><a href="#"></a></li>
	   </ul>
	 </div>
	 <div class="col-md-4">
	   <p>Enroll now</p>
	   <ul>
	   	<li><button class="btn btn-primary"> <i class="fa fa-"/></i> Apply now</button></li>
	   	<li><a href=""></a></li>
	   	<li><a href=""></a></li>
	   </ul>
	  </div>
	</div>
  </div>
</body>
  <link crossorigin='anonymous' href='https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css' integrity='sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN' rel='stylesheet'/>
  <link rel="stylesheet" href="css/styles.css">
  <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@500&display=swap" rel="stylesheet">
</html>
